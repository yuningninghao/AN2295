//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by win_hc08sprg.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_WIN_HC08SPRG_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       131
#define IDI_ICN_FREESCALE               131
#define IDC_LOG                         1003
#define IDC_COMBO_COMPORTS              1004
#define IDC_BT_RESCAN                   1005
#define IDC_COMBO_S19                   1006
#define IDC_BT_OPENS19                  1007
#define IDC_FL_ERASE                    1008
#define IDC_FL_BCHECK                   1009
#define IDC_FL_PROGRAM                  1010
#define IDC_FL_COMPARE                  1011
#define IDC_FL_AUTOPROG                 1012
#define IDC_CONNECT                     1013
#define IDC_COMBO_COMSPEED              1014
#define IDC_LbProtocVersion             1015
#define IDC_FL_READ                     1016
#define IDC_LbVersionStr                1017
#define IDC_LbMcuInfoStr                1017
#define IDC_LbDevId                     1018
#define IDC_LbMemBlkCnt                 1019
#define IDC_LbMem                       1019
#define IDC_LbMemBlk1                   1020
#define IDC_LbFlashPrty                 1020
#define IDC_LbMemBlk2                   1021
#define IDC_LbVectors                   1021
#define IDC_LbEraseBlkSize              1022
#define IDC_LbWriteBlkSize              1023
#define IDC_LbVectTableOrig             1024
#define IDC_LbVectTableNew              1025
#define IDC_CHECK_SINGLEW               1026
#define IDC_EDIT_CHECKSUM               1027
#define IDC_CHECK_SINGLEW2              1028
#define IDC_CHECK_VERIFY                1028
#define IDC_EDIT_CHECKSUM2              1029
#define IDC_FL_CHECKSUM                 1030
#define IDC_CHECK_SINGLEW3              1031
#define IDC_CHECK_SHORT_TRIM            1031
#define IDC_TAB1                        1033
#define IDC_PB_PROGRESS                 1034
#define IDC_PICTURE                     1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
