//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by win_blsrconv.rc
//
#define IDD_WIN_BLSRCONV_DIALOG         102
#define IDR_MAINFRAME                   131
#define IDI_ICON1                       130
#define IDI_FSL_ICON                    130
#define IDC_COMBO_CTMS19                1000
#define IDC_BUTTON_OPENCTMS19           1001
#define IDC_COMBO_BOOTS19               1002
#define IDC_BUTTON_OPENBOOTS19          1003
#define IDC_BUTTON_CONVERT              1004
#define IDC_COMBO_MCUTYPE               1005
#define IDC_EDIT_ORIGVECT               1006
#define IDC_EDIT_REDIRVECT              1007
#define IDC_EDIT_LOG                    1008
#define IDC_EDIT_OUTS19                 1009
#define IDC_COMBO_BOOTPROTO             1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
